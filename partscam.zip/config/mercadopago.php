<?php

return [
	'app_id'     => env('MP_APP_ID', ''),
	'app_secret' => env('MP_APP_SECRET', '')
];