<div class="wrapper-pagos wrapper py-5">
    <div class="container">
        <h3 class="title text-uppercase">{{$datos["contenido"]["CONTENIDO"]["titulo"]}}</h3>
        <div class="texto">
            {!! $datos["contenido"]["CONTENIDO"]["texto"] !!}
        </div>
    </div>
</div>