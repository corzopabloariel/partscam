
<div class="container py-5">
    <div class="jumbotron text-white bg-success">
        <h1 class="display-4">Compra realizada</h1>
        <p class="lead">Su compra ha sido procesado con éxito.</p>
    </div>
</div>