<?php $__env->startSection('body'); ?>
    <?php echo $__env->make($view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $("body").on("click",".alert button.close", function() {
            $(this).closest(".alert").remove();
        });

        if($("#sidebar").find(`a[href="${window.url}"]`).data("link") == "u") {
            $("#sidebar").find(`a[href="${window.url}"]`).addClass("active");
            $("#sidebar").find(`a[href="${window.url}"]`).closest("ul").addClass("show");
            $("#sidebar").find(`a[href="${window.url}"]`).closest("ul").prev().attr("aria-expanded",true).parent().addClass("active");
        } else
            $("#sidebar").find(`a[href="${window.url}"]`).parent().addClass("active");
    });
</script>
<?php echo $__env->yieldPushContent('scripts_distribuidor'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('page.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/distribuidor.blade.php ENDPATH**/ ?>