<div id="menuNav" class="modal fade menuNav" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content border-top-0 border-left-0 border-bottom-0">
            <div class="modal-header bg-light">
                <h5 class="modal-title">Menú</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item text-uppercase"><a href="/">Home</a></li>
                    <li class="list-group-item text-uppercase"><a href="<?php echo e(route('empresa')); ?>">Empresa</a></li>
                    <li class="list-group-item text-uppercase"><a href="<?php echo e(URL::to('productos')); ?>">Productos</a></li>
                    <li class="list-group-item text-uppercase"><a href="<?php echo e(URL::to('productos/ofertas')); ?>">Ofertas</a></li>
                    <li class="list-group-item text-uppercase"><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                </ul>
            </div>
            <div class="modal-footer bg-light">
                
            </div>
        </div>
    </div>
</div>


<nav class="navbar navbar-expand-lg navbar-light p-0 shadow-sm">
    <div class="container">
        <a class="navbar-brand position-absolute" href="<?php echo e(URL::to( '/' )); ?>">
            <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($datos['empresa']['images']['logo'])); ?>?t=<?php echo time(); ?>" />
        </a>
        <div class="row justify-content-end w-100">
            <div class="col-12 d-none col-lg-9 d-flex flex-column pt-3 pr-0" style="margin-right: -15px">
                <ul class="list-unstyled d-flex justify-content-end align-items-center info">
                    <li class="hidden-tablet"><a class="d-flex align-items-center" href="tel:<?php echo e($datos['empresa']['telefono']['tel'][0]); ?>"><i class="fas fa-phone-volume"></i><?php echo e($datos['empresa']['telefono']['tel'][0]); ?></a></li>
                    <li><a class="d-flex align-items-center" href="https://wa.me/<?php echo e($datos['empresa']['telefono']['wha'][0]); ?>"><i class="fab fa-whatsapp"></i><?php echo e($datos['empresa']['telefono']['wha'][0]); ?></a></li>
                    <li class="hidden-tablet d-flex align-items-center">
                        <span class="text-truncate d-inline-block"><i class="far fa-clock"></i><?php echo $datos['empresa']['horario']; ?></span>
                    </li>
                    <li>
                        <form method="post" action="<?php echo e(url('/buscador/header')); ?>" class="position-relative">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                            <input type="text" name="input" placeholder="Buscar..." id="">
                            <i class="fas fa-search position-absolute"></i>
                        </form>
                    </li>
                </ul>
                <ul class="list-unstyled menu d-flex justify-content-end align-items-center">
                    <li class="hidden-tablet"><a href="<?php echo e(route('empresa')); ?>">empresa</a></li>
                    <li class="hidden-tablet">
                        <a href="<?php echo e(URL::to('productos')); ?>">productos</a>
                        <ul class="submenu list-unstyled">
                            <?php $__currentLoopData = $datos["familias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(URL::to('productos/familia/' . $i)); ?>"><?php echo e($f["nombre"]); ?></a>
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $f["sub"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ii => $ff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(URL::to('productos/categoria/' . $ii)); ?>"><?php echo e($ff); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="hidden-tablet"><a href="<?php echo e(URL::to('productos/ofertas')); ?>">ofertas</a></li>
                    <li class="hidden-tablet"><a href="<?php echo e(route('contacto')); ?>">contacto</a></li>
                    <li class="menuBTN">
                        <button class="navbar-toggler" type="button" data-toggle="modal" data-target="#menuNav">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <a id="carritoHeader" class="btn shadow-sm" href="">
                            Carrito (<span class="">0</span>)
                            <i class="fas fa-shopping-cart"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/general/header.blade.php ENDPATH**/ ?>