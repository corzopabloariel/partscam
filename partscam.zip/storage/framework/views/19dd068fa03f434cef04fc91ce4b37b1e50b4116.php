<nav class="navbar navbar-expand-lg navbar-light p-0 shadow-sm">
    <div class="container">
        <a class="navbar-brand position-absolute" href="<?php echo e(URL::to( '/' )); ?>">
            <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($datos['empresa']['images']['logo'])); ?>?t=<?php echo time(); ?>" />
        </a>
        <div class="row justify-content-end w-100">
            <div class="col-10 col-lg-9 d-flex flex-column pt-3 pr-0" style="margin-right: -15px">
                <ul class="list-unstyled d-flex justify-content-end align-items-center info">
                    <li><a href="tel:<?php echo e($datos['empresa']['telefono']['tel'][0]); ?>"><i class="fas fa-phone-volume"></i><?php echo e($datos['empresa']['telefono']['tel'][0]); ?></a></li>
                    <li><a href="https://wa.me/<?php echo e($datos['empresa']['telefono']['wha'][0]); ?>"><i class="fab fa-whatsapp"></i><?php echo e($datos['empresa']['telefono']['wha'][0]); ?></a></li>
                    <li><i class="far fa-clock"></i><?php echo $datos['empresa']['horario']; ?></li>
                    <li>
                        <form action="<?php echo e(url('/buscador/header')); ?>" class="position-relative">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                            <input type="text" name="input" style="width:150px" placeholder="Buscar..." id="">
                            <i class="fas fa-search position-absolute"></i>
                        </form>
                    </li>
                </ul>
                <ul class="list-unstyled menu d-flex justify-content-end align-items-center">
                    <li><a href="<?php echo e(route('empresa')); ?>">empresa</a></li>
                    <li>
                        <a href="<?php echo e(URL::to('productos')); ?>">productos</a>
                        <ul class="submenu list-unstyled">
                            <?php $__currentLoopData = $datos["familias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL::to('productos/familia/' . $i)); ?>"><?php echo e($f); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(URL::to('productos/ofertas')); ?>">ofertas</a></li>
                    <li><a href="<?php echo e(route('contacto')); ?>">contacto</a></li>
                    <li><a class="btn shadow rounded-0"><i class="fas fa-shopping-cart mr-2"></i>compra online</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/general/header.blade.php ENDPATH**/ ?>