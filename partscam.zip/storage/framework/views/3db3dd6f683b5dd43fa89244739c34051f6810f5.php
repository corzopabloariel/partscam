<?php $__env->startPush("styles"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<link href="<?php echo e(asset('css/alertifyjs/alertify.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<div class="modal" id="modalConsulta" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="post">
                <div class="modal-body">
                    <input type="hidden" name="productoIDinput" id="productoIDinput" value="0">
                    <div class="alert alert-warning" role="alert">
                        Se enviará una consulta del producto por la cantidad de <span id="cantidadFORM"></span>
                    </div>
                    <div class="form-group">
                        <input type="text" required name="nombre" class="form-control" placeholder="Nombre completo *">
                    </div>
                    <div class="form-group">
                        <input type="email" required name="email" class="form-control" id="email" placeholder="Email *">
                    </div>
                    <div class="form-group">
                        <textarea name="consulta" id="" cols="30" class="form-control"></textarea>
                    </div>
                    <small class="form-text text-muted">* campos necesarios</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary">Consultar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="wrapper-producto">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar">
                    <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 class="title mb-1 nombre text-left <?php if($id == $datos['familia']['id']): ?> active <?php endif; ?>">
                            <a href="<?php echo e(URL::to('productos/familia/'. $id)); ?>"><?php echo e($dato["titulo"]); ?></a>
                        </h3>
                        <?php if(count($dato["hijos"]) > 0): ?>
                            <ul class="list-group <?php if($dato['activo']): ?> active-submenu <?php endif; ?>">
                            <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $did => $ddato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('page.parts.general._menuItem', ['id' => $did,'dato' => $ddato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row wrapper">
                    <div class="col-12 col-lg-6">
                        <?php if(count($datos["imagenes"]) > 0): ?>
                        <div id="carouselExampleIndicators" class="carouselProducto carousel slide wrapper-slider position-relative" data-ride="carousel">
                            <?php if(!empty($datos["oferta"])): ?>
                                <img class="position-absolute oferta" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" style="z-index: 11;left: -7px;top: -7px;" />
                            <?php endif; ?>
                            <ol class="carousel-indicators">
                                <?php for($i = 0 ; $i < count($datos["imagenes"]) ; $i++): ?>
                                    <?php if($i == 0): ?>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
                                    <?php else: ?>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </ol>
                            <div class="carousel-inner">
                                <?php for($i = 0 ; $i < count($datos["imagenes"]) ; $i++): ?>
                                <?php if($i == 0): ?>
                                    <div class="carousel-item active">
                                <?php else: ?>
                                    <div class="carousel-item">
                                <?php endif; ?> 
                                    <img class="d-block w-100" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($datos['imagenes'][$i]['image'])); ?>" >
                                </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-12 col-lg-6 detalles">
                        <h3 class="title" style="color: #2D3E75;"><?php echo e($datos["producto"]["nombre"]); ?></h3>
                        <?php if(!is_null($datos["producto"]["codigo"])): ?>
                            <p class="text-uppercase">Cód. del producto: <span><?php echo e($datos["producto"]["codigo"]); ?></span></p>
                        <?php endif; ?>
                        <?php if($datos["stock"]["cantidad"] > 0): ?>
                            <p class="text-uppercase"><span>Artículo disponible</span></p>
                        <?php else: ?>
                            <p class="text-uppercase"><span>Sin Stock</span></p>
                        <?php endif; ?>

                        <?php if(empty($datos["oferta"])): ?>
                            <h3 class="title price">$<?php echo e($datos["precio"]); ?></h3>
                        <?php else: ?>
                            <h3 class="title price d-flex justify-content-between"><strike class="mr-2" style="color:#A0A3A5; font-weight: normal">$<?php echo e($datos["precio"]); ?></strike> $<?php echo e($datos["oferta"]); ?></h3>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between w-100 align-items-start mt-4">
                            <div class="d-flex cantidad flex-column align-items-center w-50 text-uppercase">
                                <div><small class="mr-2">cantidad</small><input type="number" value="1" class="form-control form-control-sm" name="" min="1" data-max="<?php echo e($datos['stock']['cantidad']); ?>" id="cantidad"></div>
                                <small class="d-flex align-items-center justify-content-center w-100" id="consultarTEXT" style="margin-top: 10px;"></small>
                            </div>
                            <div class="d-flex align-items-start flex-column w-50">
                                <?php if($datos["stock"]["cantidad"] > 0): ?>
                                <button onclick="addCarrito(this,<?php echo e($datos['producto']['id']); ?>)" class="btn btn-sm btn-carrito btn-block text-uppercase" id="btnADD"><i class="fas fa-shopping-cart mr-2"></i><small>añadir a carrito</small></button>
                                <?php else: ?>
                                <button data-toggle="modal" data-target="#modalConsulta" onclick="consultar(this,<?php echo e($datos['producto']['id']); ?>)" class="btn btn-warning mb-2 btn-block text-uppercase" id="btnCONSULTAR"><i class="fas fa-question-circle mr-2"></i>consultar</button>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex align-items-center flex-column">
                                <?php if(!empty($datos["producto"]['mercadolibre'])): ?>
                                    <a href="<?php echo e($datos['producto']['mercadolibre']); ?>" class="mt-2" target="blank"><img src="<?php echo e(asset('images/general/mercadolibre.jpg')); ?>" /></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="title mt-5">Productos Relacionados</p>
                <div class="wrapper-oferta">
                    <div class="row">
                        <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $image = null;
                            $imagenes = $p->imagenes;
                            $precio = $p->precio["precio"];
                            
                            $oferta = $p->oferta;
                            if(count($imagenes))
                                $image = $imagenes[0]["image"];
                        ?>
                        <div class="col-lg-4 col-md-6 col-12 my-2">
                            <a href="<?php echo e(URL::to('productos/producto/' . $p['id'])); ?>" class="position-relative oferta title">
                                <?php if(!empty($oferta)): ?>
                                    <img class="position-absolute oferta" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                                <?php endif; ?>
                                <img class="d-block w-100" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($image)); ?>?t=<?php echo time(); ?>" />
                                <div class="py-2 px-3 border">
                                    <p class="text-center mb-0 text-truncate"><small><?php echo e($p["nombre"]); ?></small></p>
                                    <div class="d-flex justify-content-center">
                                        <?php if(!empty($oferta)): ?>
                                            <strike class="mr-2">$ <?php echo e(number_format($oferta["precio"],2,",",".")); ?></strike>
                                        <?php endif; ?>
                                        <span>$ <?php echo e(number_format($precio,2,",",".")); ?></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script src="<?php echo e(asset('js/alertify.min.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://jqueryui.com/resources/demos/external/jquery-mousewheel/jquery.mousewheel.js"></script>
<script>
    if($("#cantidad").length)
        $( "#cantidad" ).spinner();
    consultar = function(t, idProducto) {
        if(window.consultarINT === undefined) window.consultarINT = 1;
        $("#cantidadFORM").text((window.consultarINT == 1 ? "1 unidad" : `${window.consultarINT} unidades`));
        $("#productoIDinput").val(idProducto);
    }
    addCarrito = function(t,idProducto) {
        let cantidad = $("#cantidad");
        let max = cantidad.data("max");
        
        if(localStorage.carrito == undefined) 
            localStorage.setItem("carrito","{}");
        window.session = JSON.parse(localStorage.carrito);

        if(window.session[idProducto] === undefined) {
            window.session[idProducto] = parseInt(cantidad.val());
            localStorage.carrito = JSON.stringify(window.session);
            $("#carritoHeader").find("span").text(Object.keys(window.session).length);
            
            alertify.success('Producto agregado');
        } else {
            if(max >= parseInt(cantidad.val()) + parseInt(window.session[idProducto])) {
                window.session[idProducto] = parseInt(window.session[idProducto]) + parseInt(cantidad.val());
                localStorage.carrito = JSON.stringify(window.session);
                $("#carritoHeader").find("span").text(Object.keys(window.session).length);
                
                alertify.success('Producto agregado');
            } else {
                if(window.consultarINT === undefined) window.consultarINT = 0;
                window.consultarINT += parseInt(cantidad.val());
                
                $("#consultarTEXT").text(`Consulta por: ${window.consultarINT}`);
                if(!$("#btnCONSULTAR").length)
                    $("#btnADD").parent().append(`<button data-toggle="modal" data-target="#modalConsulta" onclick="consultar(this,${idProducto})" class="btn btn-sm btn-block btn-warning mb-2 text-uppercase" id="btnCONSULTAR"><small><i class="fas fa-question-circle mr-2"></i>consultar</small></button>`);
                alertify.notify('Producto supera el stock disponible', 'warning');
            }
        }
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/productoGeneral.blade.php ENDPATH**/ ?>