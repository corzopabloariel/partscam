<div class="wrapper-producto">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar">
                    <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 class="title mb-1 nombre text-left <?php if($id == $datos['familia']['id']): ?> active <?php endif; ?>">
                            <a href="<?php echo e(URL::to('productos/familia/'. $id)); ?>"><?php echo e($dato["titulo"]); ?></a>
                        </h3>
                        <?php if(count($dato["hijos"]) > 0): ?>
                            <ul class="list-group <?php if($dato['activo']): ?> active-submenu <?php endif; ?>">
                            <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $did => $ddato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('page.parts.general._menuItem', ['id' => $did,'dato' => $ddato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row wrapper">
                    <div class="col-12 col-md-6"></div>
                    <div class="col-12 col-md-6"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/productoGeneral.blade.php ENDPATH**/ ?>