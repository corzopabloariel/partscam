<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/slick.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('css/slick-theme.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopPush(); ?>
<div id="carouselExampleIndicators" class="carousel slide wrapper-slider" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>
    <div class="carousel-inner">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img class="d-block w-100" src="<?php echo e(asset('' . $datos['slider'][$i]['image'])); ?>" >
            <div class="carousel-caption position-absolute w-100 h-100" style="top: 0; left: 0;">
                <div class="container position-relative h-100">
                    <div class="position-absolute texto">
                        <?php echo $datos['slider'][$i]['texto']; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>
<div class="wrapper-marcas hidden-tablet">
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="regular slider" id="marcas">
                    <?php $__currentLoopData = $datos["marcas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="h-100 d-flex align-items-center justify-content-center">
                            <img src="<?php echo e(asset('' . $m['image'])); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="wrapper-producto wrapper py-2">
    <div class="container">
        <fieldset>
            <legend>productos</legend>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $datos["prodfamilias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(URL::to('productos/familia/' . $f['id'])); ?>" class="col-6 col-lg-3 my-2 position-relative">
                    <div class="img position-relative">
                        <div></div>
                        <i class="fas fa-plus"></i>
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" src="<?php echo e('' . $f['image']); ?>" alt="<?php echo e($f['nombre']); ?>">
                    </div>
                    <p class="title nombre mb-0 text-truncate"><?php echo e($f["nombre"]); ?></p>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </fieldset>
    </div>
</div>
<div class="wrapper-buscador d-flex align-items-center">
    <div class="container d-flex w-100">
        <div class="row w-100">
            <div class="col-12 col-lg-7">
                <p class="title">¡Encontrá la pieza que tu camión necesita!</p>
                <p>Buscá por código, modelo o nombre del repuesto</p>
            </div>
            <div class="col-12 col-lg-5 d-flex align-items-center">
                <form method="post" action="<?php echo e(url('/buscador/home')); ?>" class="position-relative w-100">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <input type="text" name="input" placeholder="Buscar Producto" class="form-control rounded-0 border-0" name="" id="">
                    <i class="fas fa-search position-absolute"></i>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="wrapper-oferta wrapper py-5">
    <div class="container">
        <fieldset>
            <legend>Ofertas</legend>
        
            <div class="row justify-content-center">
            <?php $__currentLoopData = $datos["ofertas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 col-12">
                    <a href="<?php echo e(URL::to('productos/producto/' . $o['producto_id'])); ?>" class="position-relative oferta title">
                        <div class="img position-relative">
                            <img class="position-absolute oferta" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                            <div></div>
                            <i class="fas fa-plus"></i>
                            <img class="d-block w-100 border border-bottom-0" src="<?php echo e(asset('' . $o['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" alt="<?php echo e($o['producto']); ?>" srcset=""/>
                        </div>
                        <div class="py-2 px-3 border">
                            <p class="text-center text-truncate mx-auto mb-0"><?php echo e($o["producto"]); ?></p>
                            <div class="d-flex justify-content-between">
                                <strike>$ <?php echo e($o["precioAnterior"]); ?></strike>
                                <span>$ <?php echo e($o["precio"]); ?></span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </fieldset>
    </div>
</div>

<div class="iconos py-5 d-flex justify-content-center">
    <ul class="d-flex justify-content-center border px-5 py-3 rounded-pill">
        <?php $__currentLoopData = $datos["contenido"]["iconos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="d-flex align-items-center">
            <img src="<?php echo e(asset($i['image'])); ?>" class="mr-2" srcset="">
            <?php echo $i["texto"]; ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<div class="repuestos py-5 bg-white">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <img src="<?php echo e(asset($datos['contenido']['repuestos']['images'])); ?>" class="w-100 d-block">
            </div>
            <div class="col-12 col-md-6">
                <div class="title"><?php echo $datos['contenido']['repuestos']['frases']; ?></div>
                <div class="row mt-3 repuesto">
                    <?php $__currentLoopData = $datos["contenido"]["repuestos"]["repuesto"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 d-flex align-items-center mt-2">
                        <img src="<?php echo e(asset($r['image'])); ?>" alt="" srcset="">
                        <span class="ml-4"><?php echo e($r["texto"]); ?></span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="servicio d-flex align-items-center">
    <div class="container w-100">
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <h4 class="mb-0 title">Más de 40 años al servicio de nuestros clientes<span class="w-75"></span></h4>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $datos["servicios"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-3">
                <img src="<?php echo e(asset($s['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="d-block mx-auto mb-2" alt="" srcset="">
                <p class="text-center mb-0"><?php echo e($s["titulo"]); ?></p>
                <p class="text-center mb-0"><?php echo e($s["subtitulo"]); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="wrapper-contacto bg-light py-5">
    <div class="container">
        <fieldset>
            <legend>consulte</legend>
            <form action="<?php echo e(url('/form/contacto')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-12">
                        <input placeholder="Nombre y Apellido / Empresa *" required type="text" value="<?php echo e(old('empresa')); ?>" name="empresa" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <input placeholder="Email *" required type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
                    </div>
                    <div class="col-lg-6 col-12">
                        <input placeholder="Teléfono" type="phone" name="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-12">
                        <input type="text" name="marca" readonly value="IVECO" class="form-control">
                    </div>
                    <div class="col-lg-4 col-12">
                        <input type="text" name="modelo" placeholder="Modelo" value="<?php echo e(old('modelo')); ?>" class="form-control">
                    </div>
                    <div class="col-lg-4 col-12">
                        <input type="number" name="anio" placeholder="Año" value="<?php echo e(old('anio')); ?>" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <textarea name="mensaje" rows="5" placeholder="Consulta" class="form-control"><?php echo e(old('mensaje')); ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="g-recaptcha" data-sitekey="6Lf8ypkUAAAAAKVtcM-8uln12mdOgGlaD16UcLXK"></div>
                    </div>
                    <div class="col-lg-6 col-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="1" name="terminos" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Acepto los términos y condiciones de privacidad
                        </label>
                    </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-g text-white text-uppercase">enviar</button>
                    </div>
                </div>
            </form>
        </fieldset>
    </div>
</div>
<div class="wrapper-entrega">
    <div class="container d-flex justify-content-center align-items-center">
        <div class="text-right mr-2"><?php echo $datos["contenido"]["CONTENIDO"]["texto"]; ?></div>
        <img src="<?php echo e(asset($datos['contenido']['CONTENIDO']['image'])); ?>" alt="" srcset="">
    </div>
</div>
<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/index.blade.php ENDPATH**/ ?>