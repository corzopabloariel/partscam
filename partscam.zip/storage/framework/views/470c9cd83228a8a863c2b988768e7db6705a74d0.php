<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <h1>Bienvenido</h1>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/adm/view/index.blade.php ENDPATH**/ ?>