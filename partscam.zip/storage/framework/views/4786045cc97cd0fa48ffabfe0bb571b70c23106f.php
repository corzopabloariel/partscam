
<div class="wrapper-carrito py-5">
    <div class="container">
        <div class="wrapper-oferta">
            <?php
            $texto = "";
            if(count($datos["resultados"]) == 0)
                $texto = "No se encontraron resultados";
            else if(count($datos["resultados"]) == 1)
                $texto = "Se ha encontrado 1 resultado";
            else
                $texto = "Se han encontrado " . count($datos["resultados"]) . " resultados";
            ?>
            <p><?php echo e($texto); ?> para su búsqueda <strong>"<?php echo e($datos["buscar"]); ?>"</strong>.</p>
            <div class="row">
                <?php $__currentLoopData = $datos["resultados"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $image = null;
                    
                    $imagenes = $p->imagenes;
                    $precio = $p->precio["precio"];
                    
                    $oferta = $p->oferta;
                    if(count($imagenes))
                        $image = $imagenes[0]["image"];
                ?>
                <div class="col-lg-3 col-md-6 col-12 my-2">
                    <a href="<?php echo e(URL::to('productos/producto/' . $p['id'])); ?>" class="position-relative oferta title">
                        <?php if(!empty($oferta)): ?>
                            <img class="position-absolute oferta" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                        <?php endif; ?>
                        <img class="d-block w-100" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" src="<?php echo e(asset($image)); ?>?t=<?php echo time(); ?>" />
                        <div class="py-2 px-3 border">
                            <p class="text-center mb-0"><small><?php echo e($p["nombre"]); ?></small></p>
                            <div class="d-flex justify-content-center">
                                <?php if(!empty($oferta)): ?>
                                    <strike class="mr-2">$ <?php echo e(number_format($oferta["precio"],2,",",".")); ?></strike>
                                <?php endif; ?>
                                <span>$ <?php echo e(number_format($precio,2,",",".")); ?></span>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="<?php echo e(asset('js/alertify.min.js')); ?>"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://jqueryui.com/resources/demos/external/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js"></script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/buscador.blade.php ENDPATH**/ ?>