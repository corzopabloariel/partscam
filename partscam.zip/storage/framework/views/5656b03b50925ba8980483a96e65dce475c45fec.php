<!DOCTYPE html>
<html>
<body>
	<h2>PARTSCAM</h2>
    <?php if(isset($cancelado)): ?>
        <h3>Cancelación de pedido</h3> 
        <br>
        <br>
        <h3>Código de transacción: <?php echo e($transaccion["codigo"]); ?></h3>

    <?php else: ?>
        <h3>Pedido</h3> 
        <p>Enviado desde la web</p>
        <br>
        <br>
        <h3>Código de transacción: <?php echo e($transaccion["codigo"]); ?></h3>
        <?php if($transaccion["tipopago"] == "MP"): ?>
            <p>Estado: Pendiente de pago electrónico</p>
        <?php elseif($transaccion["tipopago"] == "TB"): ?>
            <p>Estado: Pendiente de transferencia</p>
        <?php else: ?>
            <p>Estado: Pendiente - El cliente se acerca al local</p>
        <?php endif; ?>
    <?php endif; ?>
	<br>
	<h3>Persona</h3>
	<ul>
        <li><strong>Nombre:</strong> <?php echo e($persona["nombre"]); ?> <?php echo e($persona["apellido"]); ?></li>
        <?php if(!empty($persona["telefono"])): ?>
        <li><strong>Télefono:</strong> <?php echo e($persona["telefono"]); ?></li>
        <?php endif; ?>
        <?php if(!empty($persona["cuit"])): ?>
        <li><strong>CUIT:</strong> <?php echo e($persona["cuit"]); ?></li>
        <?php endif; ?>
        <li><strong>Condición frente al IVA:</strong> <?php echo e($persona->iva["nombre"]); ?></li>
        <li><strong>Domicilio:</strong> <?php echo e($persona["domicilio"]); ?>. <?php echo e($persona->provincia["nombre"]); ?>, <?php echo e($persona->localidad["nombre"]); ?></li>
		<li><strong>Email:</strong> <a href="mailto:<?php echo e($persona['email']); ?>"><?php echo e($persona['email']); ?></a></li>
	</ul>
    <br>
    <h4>Productos:</h4>
    <table style="width:100%">
        <thead>
            <th style="background: #dedede; text-align:left; padding: 5px;">Código</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Nombre</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Familia</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Cantidad</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Precio</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto["codigo"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto["nombre"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto->familia["nombre"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->cantidad); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;">$ <?php echo e(number_format($p["precio"],2,",",".")); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <h3 style="text-align:right;padding: 5px">Total: $ <?php echo e(number_format($transaccion["total"],2,",",".")); ?></h3>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/form/pedido.blade.php ENDPATH**/ ?>