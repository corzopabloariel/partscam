<li class="list-group-item <?php if($dato['activo']): ?> active-menu <?php endif; ?>">
    <?php if(isset($dato["modelos"])): ?> 
        <span class="d-block position-relative">
            <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id)); ?>"><?php echo e($dato["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
        </span>
        <?php if(count($dato["modelos"]) > 0): ?>
            <ul class="list-group <?php if($dato['activo']): ?> active-submenu <?php endif; ?>">
            <?php $__currentLoopData = $dato["modelos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('page.parts.general._menuItem', [ 'id' => $id,'dato' => $dato ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>
</li><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/general/_menuItem.blade.php ENDPATH**/ ?>