<h3 class="title"><?php echo e($title); ?></h3>

<section class="mt-3">
    <div class="container-fluid">
        <?php echo $__env->make('adm.parts.contenido.elemento.' . $seccion, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/adm/parts/contenido/edit.blade.php ENDPATH**/ ?>