<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/slick.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('css/slick-theme.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopPush(); ?>

<div class="wrapper-producto">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <button class="btn btn-primary text-uppercase d-block d-sm-none mb-2" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Productos
                </button>
                <div class="sidebar collapse dont-collapse-sm" id="collapseExample">
                    <div class="sidebar">
                        <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3 class="title mb-1 nombre text-left <?php if($id == $datos['familia']['id']): ?> active <?php endif; ?>">
                                <a href="<?php echo e(URL::to('productos/familia/'. $id)); ?>"><?php echo e($dato["nombre"]); ?></a>
                            </h3>
                            <?php if(isset($datos["productos"])): ?>
                                <ul class="list-group">
                                    <?php $__currentLoopData = $dato["modelos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo_id => $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item <?php if($modelo['activo'] == 1): ?> active-menu <?php endif; ?>">
                                        <span class="d-block position-relative">
                                            <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id . '/modelo/' . $modelo_id . '/' . $modelo['tipo'])); ?>"><?php echo e($modelo["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
                                        </span>
                                        <?php if(isset($modelo["categorias"])): ?>
                                        <ul class="list-group <?php if($modelo['activo'] == 1): ?>  active-submenu <?php endif; ?>">
                                            <?php $__currentLoopData = $modelo["categorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria_id => $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item <?php if($categoria['activo'] == 1): ?> active-menu <?php endif; ?>">
                                                <span class="d-block position-relative">
                                                    <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id . '/modelo/' . $modelo_id . '/categoria/' . $categoria_id . '/' . $categoria['tipo'])); ?>"><?php echo e($categoria["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
                                                </span>
                                                <?php if(isset($categoria["subcategorias"])): ?>
                                                <ul class="list-group <?php if($categoria['activo'] == 1): ?>  active-submenu <?php endif; ?>">
                                                    <?php $__currentLoopData = $categoria["subcategorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria_id => $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item <?php if($subcategoria['activo'] == 1): ?> active-menu <?php endif; ?>">
                                                        <span class="d-block position-relative">
                                                            <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id . '/modelo/' . $modelo_id . '/categoria/' . $categoria_id . '/subcategoria/' . $subcategoria_id . '/' . $subcategoria['tipo'])); ?>"><?php echo e($subcategoria["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
                                                        </span>
                                                        <?php if(isset($categoria["ssubcategorias"])): ?>
                                                        <ul class="list-group <?php if($subcategoria['activo'] == 1): ?>  active-submenu <?php endif; ?>">
                                                            <?php $__currentLoopData = $categoria["ssubcategorias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria_id => $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="list-group-item <?php if($ssubcategoria['activo'] == 1): ?> active-menu <?php endif; ?>">
                                                                <span class="d-block position-relative">
                                                                    <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id . '/modelo/' . $modelo_id . '/categoria/' . $categoria_id . '/subcategoria/' . $subcategoria_id . '/ssubcategoria/' . $ssubcategoria['id'] . '/' . $ssubcategoria['tipo'])); ?>"><?php echo e($ssubcategoria["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
                                                                </span>
                                                            </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                                <?php endif; ?>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php endif; ?>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <?php if(count($dato["modelos"]) > 0): ?>
                                    <ul class="list-group">
                                    <?php $__currentLoopData = $dato["modelos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo_id => $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item <?php if($modelo['activo'] == 1): ?> active-menu <?php endif; ?>">
                                        <span class="d-block position-relative">
                                            <a class="d-block" href="<?php echo e(URL::to('productos/familia/' . $id . '/modelo/' . $id . '/1')); ?>"><?php echo e($modelo["nombre"]); ?></a><i class="fas fa-angle-down position-absolute"></i><i class="fas fa-angle-right position-absolute"></i>
                                        </span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-12 d-flex justify-content-end">
                        <div class="d-flex justify-content-end ordenamiento py-3 w-100 border-top border-bottom">
                        <div class="text-uppercase d-flex align-items-center hidden-tablet">vista:<i onclick="ordenamiento(this,1)" class="activo fas fa-th-large ml-2"></i><i onclick="ordenamiento(this,2)" class="fas fa-th-list ml-2"></i></div>
                            <select onchange="ordenar(this)" name="" style="width:auto !important;" class="text-uppercase bg-light form-control rounded-0 ml-3" id="">
                                <option value="ASC" <?php if($datos["order"] == "ASC"): ?> selected <?php endif; ?>>alfabético a-z</option>
                                <option value="DESC" <?php if($datos["order"] == "DESC"): ?> selected <?php endif; ?>>alfabético z-a</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row" id="ordenamiento">
                    <?php if(isset($datos["productos"])): ?>
                        <?php $__currentLoopData = $datos["productos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $imgs = $p->imagenes;
                        $img = null;
                        if(count($imgs) > 0)
                            $img = $imgs[0]['image'];
                        $oferta = $p->oferta;
                        
                        ?>
                        <a href="<?php echo e(URL::to('productos/producto/'. $p['id'] . '/' . $datos['modelo_id'])); ?>" class="position-relative col-lg-4 col-md-6 col-12 mb-4">
                            <div class="img position-relative">
                                <?php if(!empty($oferta)): ?>
                                    <img class="position-absolute oferta" style="top: -8px; left: -8px; z-index: 11;" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                                <?php endif; ?>
                                <div></div>
                                <i class="fas fa-plus"></i>
                                <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="text-center mt-1 mb-0"><?php echo e($p['nombre']); ?></p>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php if(isset($datos["productosSIN"])): ?>
                            <?php $__currentLoopData = $datos["productosSIN"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $imgs = $p->imagenes;
                            $img = null;
                            if(count($imgs) > 0)
                                $img = $imgs[0]['image'];
                            $oferta = $p->oferta;
                            
                            ?>
                            <a href="<?php echo e(URL::to('productos/producto/'. $p['id'])); ?>" class="position-relative col-lg-4 col-md-6 col-12 mb-4">
                                <div class="img position-relative">
                                    <?php if(!empty($oferta)): ?>
                                        <img class="position-absolute oferta" style="top: -8px; left: -8px; z-index: 11;" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                                    <?php endif; ?>
                                    <div></div>
                                    <i class="fas fa-plus"></i>
                                    <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                                </div>
                                <p class="text-center mt-1 mb-0"><?php echo e($p['nombre']); ?></p>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif(isset($datos["modelos"])): ?>
                            <?php $__currentLoopData = $datos["modelos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 my-2 d-flex align-self-stretch">
                                <a href="<?php echo e(URL::to('productos/familia/'. $datos['familia']['id'] . '/modelo/'. $i . '/2')); ?>" class="border p-3 d-block categoria d-flex align-items-center w-100">
                                    <?php echo e($m); ?>

                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if(isset($datos["productos"])): ?>
                <div class="row">
                    <div class="col-12 d-flex justify-content-center"><?php echo e($datos["productos"]->links()); ?></div>
                </div>
                <?php endif; ?>
                <?php if(isset($datos["productosSIN"])): ?>
                <div class="row">
                    <div class="col-12 d-flex justify-content-center"><?php echo e($datos["productosSIN"]->links()); ?></div>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>


<div class="wrapper-marcas">
    <div class="container position-relative">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="regular slider" id="marcas">
                    <?php $__currentLoopData = $datos["marcas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="h-100 d-flex align-items-center justify-content-center">
                            <img src="<?php echo e(asset('/')); ?><?php echo e($m['image']); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    ordenamiento = function(e,tipo) {
        $(e).parent().find(".activo").removeClass("activo");
        $(e).addClass("activo");
        if(tipo == 1) 
            $("#ordenamiento").removeClass("largo");
        else
            $("#ordenamiento").addClass("largo");
    };
    ordenar = function(t) {
        let orden = $(t).val();
        let u = `${window.url}/${orden}`;
        if(u.indexOf("DESC") > 0)
            u = u.replace("/DESC","");
        if(u.indexOf("ASC") > 0)
            u = u.replace("/ASC","");
        u = `${u}/${orden}`;
        window.location = u;
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/familia.blade.php ENDPATH**/ ?>