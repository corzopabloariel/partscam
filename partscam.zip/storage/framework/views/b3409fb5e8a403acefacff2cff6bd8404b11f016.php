
<div id="carouselExampleIndicators" class="carousel slide wrapper-slider" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>
    <div class="carousel-inner">
        <?php for($i = 0 ; $i < count($datos['slider']) ; $i++): ?>
        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img class="d-block w-100" src="<?php echo e(asset($datos['slider'][$i]['image'])); ?>" >
            <div class="carousel-caption position-absolute w-100 h-100" style="top: 0; left: 0;">
                <div class="container position-relative h-100">
                    <div class="position-absolute texto">
                        <?php echo $datos['slider'][$i]['texto']; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</div>
<div class="wrapper-oferta wrapper py-5">
    <div class="container">
        <div class="row justify-content-center">
            <?php $__currentLoopData = $datos["ofertas"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $o["o"]->modelosMM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 col-12">
                        <a href="<?php echo e(URL::to('productos/producto/' . $o['producto_id'] . '/' . $m['modelo_id'])); ?>" class="position-relative oferta title">
                            <div class="img position-relative">
                                <img class="position-absolute oferta" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                                <div></div>
                                <i class="fas fa-plus"></i>
                                <img class="d-block w-100" src="<?php echo e(asset($o['image'])); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" alt="<?php echo e($o['producto']); ?>" srcset=""/>
                            </div>
                            <div class="py-2 px-3 border">
                                <p class="text-center w-75 mx-auto mb-0"><?php echo e($o["producto"]); ?></p>
                                <p class="text-center"><small><?php echo e($m->modelo["nombre"]); ?></small></p>
                                <div class="d-flex justify-content-between">
                                    <strike>$ <?php echo e($o["precioAnterior"]); ?></strike>
                                    <span>$ <?php echo e($o["precio"]); ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/ofertas.blade.php ENDPATH**/ ?>