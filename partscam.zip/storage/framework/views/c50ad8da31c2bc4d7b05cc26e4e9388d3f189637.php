<!DOCTYPE html>
<html>
<body>
	<h2>PARTSCAM</h2>
	<h3>Contacto</h3> 
	<p>Enviado desde la web</p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong> <?php echo e($nombre); ?> <?php echo e($apellido); ?></li>
		<li><strong>Télefono:</strong> <?php echo e($telefono); ?></li>
		<li><strong>Email:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
	</ul>
    <br>
    <h4>Mensaje:</h4>
    <p><?php echo e($mensaje); ?></p>
    <br>
    <?php if(!empty($marca)): ?>
        <p><strong>MARCA:</strong> <?php echo e($marca); ?></p>
    <?php endif; ?>
    <?php if(!empty($modelo)): ?>
        <p><strong>MODELO:</strong> <?php echo e($modelo); ?></p>
    <?php endif; ?>
    <?php if(!empty($anio)): ?>
        <p><strong>AÑO:</strong> <?php echo e($anio); ?></p>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/form/contacto.blade.php ENDPATH**/ ?>