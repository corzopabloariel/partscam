<div class="wrapper-producto py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $datos["prodfamilias"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(URL::to('productos/familia/' . $f['id'])); ?>" class="col-12 col-lg-5 my-2">
                        <img onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" src="<?php echo e($f['image']); ?>" alt="<?php echo e($f['nombre']); ?>">
                        <p class="title nombre mb-0"><?php echo e($f["nombre"]); ?></p>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/producto.blade.php ENDPATH**/ ?>