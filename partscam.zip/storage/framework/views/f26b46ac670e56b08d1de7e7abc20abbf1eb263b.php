<div class="d-flex align-items-center justify-content-center" style="height: 100vh;">
    <h1>Bienvenido<br/><?php echo e(Auth::user()["name"]); ?></h1>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/adm/parts/index.blade.php ENDPATH**/ ?>