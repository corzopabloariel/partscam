<!DOCTYPE html>
<html>
<body>
	<h2>PARTSCAM</h2>
	<h3>Consulta de producto</h3> 
	<p>Enviado desde la web</p>
	<br>
	<br>
	<h3>Datos del contacto</h3>
	<ul>
		<li><strong>Nombre:</strong> <?php echo e($nombre); ?></li>
		<li><strong>Email:</strong> <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a></li>
	</ul>
    <br>
    <h4>Mensaje:</h4>
    <p><?php echo e($mensaje); ?></p>
    <br>
	<h3>Producto</h3>
    <ul>
        <li><strong>Cantidad:</strong> <?php echo e($cantidad); ?></li>
        <li><strong>Nombre:</strong> <?php echo e($producto["familia"]); ?> <?php echo e($producto["nombre"]); ?></li>
    </ul>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/form/consultar.blade.php ENDPATH**/ ?>