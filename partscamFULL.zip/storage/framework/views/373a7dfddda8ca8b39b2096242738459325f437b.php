<!DOCTYPE html>
<html>
<body>
	<h2>PARTSCAM</h2>
    <?php if(isset($cancelado)): ?>
        <h3>Cancelación de compra</h3>
        <p>Hola <?php echo e($persona["nombre"]); ?></p>
        <br>
        <h3>Código de transacción: <?php echo e($transaccion["codigo"]); ?></h3>

    <?php else: ?>
        <h3>Compra</h3> 
        <p>Hola <?php echo e($persona["nombre"]); ?></p>
        <p>Detalles de la compra en <a href="https://partscam.com.ar/" target="blank">partscam.com.ar</a></p>
        <br>
        <h3>Código de transacción: <?php echo e($transaccion["codigo"]); ?></h3>
        <?php if($transaccion["tipopago"] == "MP"): ?>
            <?php echo e($textos["mp"]); ?>

        <?php elseif($transaccion["tipopago"] == "TB"): ?>
            <p><strong>BANCO:</strong> <?php echo e($textos["tb"]["banco"]); ?></p>
            <p><strong>TIPO:</strong> <?php echo e($textos["tb"]["tipo"]); ?></p>
            <p><strong>NRO:</strong> <?php echo e($textos["tb"]["nro"]); ?></p>
            <p><strong>SUC.:</strong> <?php echo e($textos["tb"]["suc"]); ?></p>
            <p><strong>NOMBRE DE LA CUENTA:</strong> <?php echo e($textos["tb"]["nombre"]); ?></p>
            <p><strong>CBU:</strong> <?php echo e($textos["tb"]["cbu"]); ?></p>
            <p><strong>CUIT:</strong> <?php echo e($textos["tb"]["cuit"]); ?></p>
            <br/>
            <p>Enviar comprobante a <a href="mailto:<?php echo e($textos['tb']['emailpago']); ?>"><?php echo e($textos['tb']['emailpago']); ?></a></p>
        <?php else: ?>
            <?php echo e($textos['pl']); ?>

        <?php endif; ?>
    <?php endif; ?>
    <br>
    <h4>Productos:</h4>
    <table style="width:100%">
        <thead>
            <th style="background: #dedede; text-align:left; padding: 5px;">Código</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Nombre</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Familia</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Cantidad</th>
            <th style="background: #dedede; text-align:left; padding: 5px;">Precio</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto["codigo"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto["nombre"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->producto->familia["nombre"]); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;"><?php echo e($p->cantidad); ?></td>
            <td style="border-bottom: 1px solid; padding: 5px;">$ <?php echo e(number_format($p["precio"],2,",",".")); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <h3 style="text-align:right;padding: 5px">Total: $ <?php echo e(number_format($transaccion["total"],2,",",".")); ?></h3>
</body>
</html><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/form/compra.blade.php ENDPATH**/ ?>