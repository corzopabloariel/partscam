
<div class="container py-5">
    <div class="jumbotron text-white bg-success">
        <h1 class="display-4">Transacción generada</h1>
        <p class="lead">La transacción fue generada con éxito. Verifique su casilla de correo con la información detallada.</p>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/confirmar/ok.blade.php ENDPATH**/ ?>