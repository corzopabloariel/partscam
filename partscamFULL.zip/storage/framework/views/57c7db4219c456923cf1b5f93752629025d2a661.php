
<div id="wrapper-form" class="mt-2">
    <div class="card">
        <div class="card-body">
            <form id="form" novalidate class="pt-2" action="<?php echo e(url('/adm/contenido/' . $seccion . '/update')); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <div class="container-form"></div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts_distribuidor'); ?>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
    $(document).on("ready",function() {
        $(".ckeditor").each(function () {
            CKEDITOR.replace( $(this).attr("name") );
        });
    });

    const src = "<?php echo e(asset('images/general/no-img.png')); ?>";
    window.pyrus = new Pyrus("terminos", null, src);
    window.contenido = <?php echo json_encode($contenido, 15, 512) ?>;
    /** ------------------------------------- */
    readURL = function(input, target) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $(`#${target}`).attr(`src`,`${e.target.result}`);
            };
            reader.readAsDataURL(input.files[0]);
        }
    };
    /** ------------------------------------- */
    init = function(callbackOK) {
        console.log("CONSTRUYENDO FORMULARIO Y TABLA");
        /** */
        $("#form .container-form").html(window.pyrus.formulario());
        setTimeout(() => {
            callbackOK.call(this);
        }, 50);
    }
    /** */
    init(function() {
        $(`[name="titulo_es"]`).val(window.contenido.data.CONTENIDO.titulo.es);
        CKEDITOR.instances[`texto_es`].setData(window.contenido.data.CONTENIDO.texto.es);
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/adm/parts/contenido/elemento/terminos.blade.php ENDPATH**/ ?>