<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/slick.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('css/slick-theme.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopPush(); ?>
<div class="wrapper-producto">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <div class="sidebar">
                    <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 class="title mb-1 nombre text-left <?php if($id == $datos['familia']['id']): ?> active <?php endif; ?>">
                            <a href="<?php echo e(URL::to('productos/familia/'. $id)); ?>"><?php echo e($dato["titulo"]); ?></a>
                        </h3>
                        <?php if(count($dato["hijos"]) > 0): ?>
                            <ul class="list-group <?php if($dato['activo']): ?> active-submenu <?php endif; ?>">
                            <?php $__currentLoopData = $dato["hijos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $did => $ddato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('page.parts.general._menuItem', ['id' => $did,'dato' => $ddato], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-12 d-flex justify-content-end">
                        <div class="d-flex justify-content-end ordenamiento py-3 w-100 border-top border-bottom">
                            <div class="text-uppercase d-flex align-items-center">vista:<i onclick="ordenamiento(this,1)" class="activo fas fa-th-large ml-2"></i><i onclick="ordenamiento(this,2)" class="fas fa-th-list ml-2"></i></div>
                            <select onchange="order(this)" style="width:auto !important;" class="text-uppercase bg-light form-control rounded-0 ml-3" id="">
                                <option value="1">alfabético a-z</option>
                                <option value="2">alfabético z-a</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row wrapper" id="ordenamiento">
                    <?php
                    for($i = 0 ; $i < count($datos["idsCategorias"]) ; $i++) {
                        if(count($datos["idsCategorias"]) - 1 == $i) {
                            if(empty($datos["menu"][$datos["idsCategorias"][$i]]["hijos"]))
                                $datos["menu"] = $datos["menu"][$datos["idsCategorias"][$i]]["productos"];
                            else
                                $datos["menu"] = $datos["menu"][$datos["idsCategorias"][$i]]["hijos"];
                        } else
                            $datos["menu"] = $datos["menu"][$datos["idsCategorias"][$i]]["hijos"];
                    }
                    ?>
                    <?php $__currentLoopData = $datos["menu"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($d['imagenes'])): ?>
                        <?php
                        $img = null;
                        $oferta = $d->oferta;
                        if(isset($d['imagenes'][0]))
                            $img = $d['imagenes'][0]['image'];
                        ?>
                        <a href="<?php echo e(URL::to('productos/producto/'. $d['id'])); ?>" class="position-relative col-lg-4 col-md-6 col-12 mb-4">
                            <div class="img position-relative">
                                <?php if(!empty($oferta)): ?>
                                    <img class="position-absolute oferta" style="top: -8px; left: -8px; z-index: 11;" src="<?php echo e(asset('images/general/ofertas.fw.png')); ?>" />
                                <?php endif; ?>
                                <div></div>
                                <i class="fas fa-plus"></i>
                                <img src="<?php echo e(asset($img)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="w-100" />
                            </div>
                            <p class="text-center mt-1 mb-0"><?php echo e($d['nombre']); ?></p>
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(URL::to('productos/categoria/'. $i)); ?>" onError="this.src='<?php echo e(asset('images/general/no-img.png')); ?>'" class="col-lg-4 col-md-6 col-12 mb-4">
                            <div class="img">
                                <div></div>
                                <i class="fas fa-plus"></i>
                                <img src="<?php echo e(asset($d['image'])); ?>" class="w-100" />
                            </div>
                            <p class="text-center mt-1 mb-0"><?php echo e($d['titulo']); ?></p>
                        </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mercadopago">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <img src="<?php echo e(asset('images/general/mercadopago.fw.png')); ?>" alt="MercadoPago" srcset="">
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    order = function(t) {
        let tipo = $(t).val();
        let items = [];
        $('#ordenamiento a').each(function() {
            let name = $(this).find("p").text(),
                pos = $(this).index;
            items.push({
                item: this,
                name: name,
                pos: pos 
            });
        });
        items.sort(function(a,b) {
            console.log(a.name.localeCompare(b.name))
            if(parseInt(tipo) == 1)
                return a.name.localeCompare(b.name);
            else {
                if(a.name.localeCompare(b.name) == 1)
                    return -1;
                return 1;
            }
        });
        let target = $('#ordenamiento');
        target.empty();
        items.forEach(function(e) {
            target.append(e.item);
        });
    }
    ordenamiento = function(e,tipo) {
        $(e).parent().find(".activo").removeClass("activo");
        $(e).addClass("activo");
        if(tipo == 1) 
            $("#ordenamiento").removeClass("largo");
        else
            $("#ordenamiento").addClass("largo");
    };
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/categoria.blade.php ENDPATH**/ ?>