<div class="wrapper-pagos wrapper py-5">
    <div class="container">
        <h3 class="title text-uppercase"><?php echo e($datos["contenido"]["CONTENIDO"]["titulo"]); ?></h3>
        <div class="texto">
            <?php echo $datos["contenido"]["CONTENIDO"]["texto"]; ?>

        </div>
    </div>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\partscam\resources\views/page/parts/terminos.blade.php ENDPATH**/ ?>